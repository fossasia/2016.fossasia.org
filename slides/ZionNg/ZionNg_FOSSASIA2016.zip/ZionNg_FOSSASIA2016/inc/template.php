<?php
/**
 * Template file for Reveal.JS presentations
 *
 * Paths for stylesheets, scripts and images are relative to the presentation folder.
 * For PHP includes, the script will look in the presentation folder first for the file,
 * followed by this folder (same folder as this template file) and lastly the include path.
 *
 * Variables that can be set by presentations before including this template file:
 *   $title      Title of presentation
 *   $headerHtml HTML to be output just before </head>
 *   $slidesFile File containing slide <section>s. Defaults to "slides.php"
 *   $footerHtml HTML to be output just before </body>
 *
 * @author  Zion Ng <zion@intzone.com>
 * @version 2016-02-06T16:30+08:00
 */

// Variables
$vars = array('title' => '', 'headerHtml' => '', 'slidesFile' => 'slides.php', 'footerHtml' => '');
foreach ($vars as $key => $value) {
    ${$key} = isset(${$key}) ? ${$key} : $value;
}

include 'functions.php';
?>
<!DOCTYPE html>
<html>

  <head>
    <title><?php echo $title; ?></title>

    <meta charset="utf-8">
    <meta name="author" content="Zion Ng, intZone.com">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, minimal-ui">

    <link rel="stylesheet" href="../inc/reveal/css/reveal.css">
    <link rel="stylesheet" href="../inc/reveal/css/theme/white.css" id="theme"> <!-- theme -->
    <link rel="stylesheet" href="../inc/reveal/lib/css/zenburn.css"> <!-- For syntax highlighting -->
    <link rel="stylesheet" href="../inc/global.css">

    <!--Add support for earlier versions of Internet Explorer -->
    <!--[if lt IE 9]>
      <script src="../inc/reveal/lib/js/html5shiv.js"></script>
    <![endif]-->
    <?php echo $headerHtml; ?>

  </head>

  <body>
    <!-- Wrap the entire slide show in a div using the "reveal" class -->
    <div class="reveal">
      <!-- Wrap all slides in a single "slides" class -->
      <div class="slides">

        <!-- ALL SLIDES GO HERE -->
        <!-- Each section element contains an individual slide -->
        <?php include $slidesFile; ?>

      </div>
    </div>

    <script src="../inc/reveal/lib/js/head.min.js"></script>
    <script src="../inc/reveal/js/reveal.js"></script>
    <script src="../inc/global.js"></script>
    <?php echo $footerHtml; ?>

  </body>
</html>
