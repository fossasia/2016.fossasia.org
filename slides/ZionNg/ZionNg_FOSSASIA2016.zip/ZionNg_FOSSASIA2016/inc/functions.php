<?php
/**
 * Common functions for all presentations
 *
 * @author  Zion Ng <zion@intzone.com>
 * @version 2016-01-26T15:00+08:00
 */

/**
 * Draw single-row table
 *
 * @param  array  $cells      Cell content
 * @param  int    $indent     Optional starting indentation
 * @param  string $tdClass    Optional CSS class for td cells, eg. "fragment"
 * @param  string $tableClass Optional CSS class for table
 * @return string
 */
function drawTable(array $cells, $indent = 10, $tdClass = '', $tableClass = 'table')
{
    $spaces = str_repeat(' ', $indent);
    $result = sprintf(
        "\n%s" . '<table class="%s">' . "\n%s  <tr>\n",
        $spaces,
        $tableClass,
        $spaces
    );

    $cellWidth = (100 / count($cells)) . '%';
    foreach ($cells as $title => $contents) {
        $result .= sprintf(
            $spaces . '    <td %s width="%s">' . "\n%s%s\n" . $spaces . "    </td>\n",
            ($tdClass ? "class=\"{$tdClass}\"" : ''),
            $cellWidth,
            (is_int($title) ? '' : "<b>{$title}</b><br><br>\n"),
            $contents
        );
    }

    $result .= $spaces . "  </tr>\n" . $spaces . "</table>\n";

    return $result;
}

/**
 * Print code block
 *
 * @param  string $text
 * @param  string $preClass  Optional CSS class for <pre>, eg. "fragment"
 * @param  string $codeClass Optional CSS class for <code>, typically to set language
 * @return string
 */
function printCode($text, $preClass = '', $codeClass = 'php')
{
    return sprintf(
        "\n" . '<pre%s><code%s>%s</code></pre>' . "\n",
        ($preClass ? " class=\"{$preClass}\"" : ''),
        ($codeClass ? " class=\"{$codeClass}\"" : ''),
        htmlspecialchars($text)
    );
}

/**
 * Print <ul> list with <li class="fragment">
 *
 * This function is recursive, allowing for printing of nested <ul> lists.
 *
 * @param  array  $list
 * @param  int    $indent    Optional starting indentation
 * @param  string $listClass Optional CSS class for top <ul>
 * @return string
 */
function printList($list, $indent = 10, $listClass = '')
{
    $spaces = str_repeat(' ', $indent);
    $result = sprintf(
        "\n%s<ul%s>\n",
        $spaces,
        ($listClass ? " class=\"{$listClass}\"" : '')
    );

    foreach ($list as $key => $value) {
        $result .= $spaces . '  <li class="fragment">';

        if (is_int($key)) {
            $result .= $value . "</li>\n";
            continue;
        }

        // Nested list
        $result .= "\n{$spaces}    {$key}"
                 . printList($value, $indent + 4)
                 . $spaces . "  </li>\n";
    }

    $result .= $spaces . "</ul>\n";
    return $result;
}
