/**
 * Global JS for all presentations
 *
 * @author  Zion Ng
 * @version 2016-01-25T22:30+08:00 zion.ng
 */

// Required, even if empty.
Reveal.initialize({
    // Note: setting width and height to percentages will mess up the overview "o" mode
    controls: true,
    progress: true,
    slideNumber: "c.v/t",
    history: true,
    center: true,
    loop: true, // go back to 1st slide which contains speaker information
    dependencies: [
        {   // Syntax highlight for <code> elements
            src: '../inc/reveal/plugin/highlight/highlight.js',
            async: true,
            callback: function () { hljs.initHighlightingOnLoad(); }
        },

        {   // Speaker notes (press "s" key) - requires localhost web server
            src: '../inc/reveal/plugin/notes/notes.js',
            async: true
        },

        {   // Load external HTML files into presentation
            src: '../inc/reveal/plugin/external/external.js',
            condition: function () { return !!document.querySelector( '[data-external]' ); }
        }
    ]
});

// Code to reflect actual slide number instead of using flattened slide number - does NOT work on speaker notes
var horzSlideCnt = document.querySelectorAll( '.reveal .slides>section' ).length;

// Update slide number for 1st slide where slidechanged event has not been triggered
Reveal.addEventListener('ready', function (event) {
    Reveal.configure({
        slideNumber: "c.1/" + horzSlideCnt
    });
});

// Update slide number to reflect actual horizontal/vertical slide numbers (indexh/indexv are zero-based)
Reveal.addEventListener('slidechanged', function (event) {
    var slideNumberField = document.querySelector('.reveal .slide-number'),
        slideNumber = (event.indexh + 1) + "." + (event.indexv + 1) + '/' + horzSlideCnt,
        interval;

    // Unable to set innerHTML straightaway without use of setInterval() as element may be re-created after event
    interval = window.setInterval(
        function () {
            slideNumberField.innerHTML = slideNumber;
            clearInterval(interval);
        },
        10
    );
});
